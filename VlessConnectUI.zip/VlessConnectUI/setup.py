#!/usr/bin/env python3
"""
Setup script для ARMT VPN
"""

from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name='armt-vpn',
    version='1.0.0',
    description='VLESS VPN Client с графическим интерфейсом',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='ARMT VPN Team',
    author_email='support@armt-vpn.local',
    url='https://github.com/armt-vpn/armt-vpn',
    license='MIT',
    packages=find_packages(),
    package_data={
        'src': ['style.css'],
    },
    include_package_data=True,
    install_requires=[
        'PyGObject>=3.30.0',
        'Pillow>=8.0.0',
        'opencv-python>=4.5.0',
        'pyzbar>=0.1.8',
        'qrcode>=7.0',
        'pyperclip>=1.8.0',
    ],
    entry_points={
        'console_scripts': [
            'armt-vpn=src.main:main',
        ],
    },
    data_files=[
        ('share/applications', ['armt-vpn.desktop']),
        ('share/pixmaps', ['attached_assets/81018241-4148-45FC-B3A9-EDFFD93CCAB3_1761563132226.png']),
    ],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: X11 Applications :: GTK',
        'Intended Audience :: End Users/Desktop',
        'License :: OSI Approved :: MIT License',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Topic :: Internet',
        'Topic :: Security',
    ],
    python_requires='>=3.6',
)
