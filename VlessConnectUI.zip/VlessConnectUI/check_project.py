#!/usr/bin/env python3
"""
Скрипт проверки проекта ARMT VPN
Проверяет синтаксис Python файлов и структуру проекта
"""

import py_compile
import os
import sys
from pathlib import Path

def check_python_syntax(file_path):
    """Проверка синтаксиса Python файла"""
    try:
        py_compile.compile(file_path, doraise=True)
        return True, None
    except py_compile.PyCompileError as e:
        return False, str(e)

def main():
    """Главная функция проверки"""
    print("=" * 60)
    print("ARMT VPN - Проверка проекта")
    print("=" * 60)
    print()
    
    errors = []
    warnings = []
    
    # Список Python файлов для проверки
    python_files = [
        'src/main.py',
        'src/vless_parser.py',
        'src/qr_handler.py',
        'src/xray_manager.py',
        'setup.py',
    ]
    
    print("[1/3] Проверка синтаксиса Python файлов...")
    for py_file in python_files:
        if os.path.exists(py_file):
            success, error = check_python_syntax(py_file)
            if success:
                print(f"  ✓ {py_file}")
            else:
                print(f"  ✗ {py_file}")
                errors.append(f"Синтаксическая ошибка в {py_file}: {error}")
        else:
            errors.append(f"Файл не найден: {py_file}")
            print(f"  ✗ {py_file} (не найден)")
    
    print()
    print("[2/3] Проверка структуры проекта...")
    
    # Проверка наличия необходимых файлов
    required_files = {
        'src/main.py': 'Главное приложение',
        'src/vless_parser.py': 'Парсер VLESS',
        'src/qr_handler.py': 'Обработчик QR',
        'src/xray_manager.py': 'Менеджер Xray-core',
        'src/style.css': 'CSS стили',
        'debian/control': 'Debian control',
        'debian/rules': 'Debian rules',
        'debian/compat': 'Debian compat',
        'debian/changelog': 'Debian changelog',
        'setup.py': 'Setup script',
        'armt-vpn.desktop': 'Desktop entry',
        'build_deb.sh': 'Скрипт сборки',
        'requirements.txt': 'Python зависимости',
        'README.md': 'Документация',
    }
    
    for file_path, description in required_files.items():
        if os.path.exists(file_path):
            print(f"  ✓ {file_path} ({description})")
        else:
            errors.append(f"Отсутствует файл: {file_path}")
            print(f"  ✗ {file_path} ({description}) - НЕ НАЙДЕН")
    
    print()
    print("[3/3] Проверка прав доступа...")
    
    executable_files = ['build_deb.sh']
    for exe_file in executable_files:
        if os.path.exists(exe_file):
            if os.access(exe_file, os.X_OK):
                print(f"  ✓ {exe_file} (исполняемый)")
            else:
                warnings.append(f"{exe_file} не имеет прав на выполнение")
                print(f"  ⚠ {exe_file} (нет прав на выполнение)")
        else:
            print(f"  ✗ {exe_file} (не найден)")
    
    print()
    print("=" * 60)
    
    # Вывод результатов
    if errors:
        print(f"❌ ОШИБКИ ({len(errors)}):")
        for error in errors:
            print(f"  • {error}")
        print()
    
    if warnings:
        print(f"⚠️  ПРЕДУПРЕЖДЕНИЯ ({len(warnings)}):")
        for warning in warnings:
            print(f"  • {warning}")
        print()
    
    if not errors and not warnings:
        print("✅ Все проверки пройдены успешно!")
        print()
        print("Проект готов к сборке!")
        print()
        print("Следующие шаги:")
        print("  1. Загрузите проект на Linux систему (Ubuntu/Debian)")
        print("  2. Установите зависимости:")
        print("     sudo apt-get install dpkg-dev debhelper dh-python")
        print("  3. Запустите сборку:")
        print("     ./build_deb.sh")
        print("  4. Установите пакет:")
        print("     sudo dpkg -i armt-vpn_1.0.0_all.deb")
        print()
    elif not errors:
        print("✅ Критических ошибок не найдено")
        print("⚠️  Но есть предупреждения, которые стоит исправить")
        print()
        sys.exit(0)
    else:
        print("❌ Обнаружены критические ошибки!")
        print("Пожалуйста, исправьте их перед сборкой")
        print()
        sys.exit(1)
    
    print("=" * 60)

if __name__ == '__main__':
    main()
