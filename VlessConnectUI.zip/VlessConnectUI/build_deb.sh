#!/bin/bash

# Скрипт сборки .deb пакета для ARMT VPN

set -e

echo "========================================="
echo "ARMT VPN - Сборка .deb пакета"
echo "========================================="
echo ""

# Проверка наличия необходимых инструментов
echo "[1/6] Проверка зависимостей..."
if ! command -v dpkg-deb &> /dev/null; then
    echo "Ошибка: dpkg-deb не найден. Установите: sudo apt-get install dpkg-dev"
    exit 1
fi

if ! command -v debuild &> /dev/null; then
    echo "Предупреждение: debuild не найден. Для полной сборки установите: sudo apt-get install devscripts"
fi

# Информация о пакете
PACKAGE_NAME="armt-vpn"
VERSION="1.0.0"
ARCH="all"

echo "Пакет: $PACKAGE_NAME"
echo "Версия: $VERSION"
echo "Архитектура: $ARCH"
echo ""

# Создание структуры пакета
echo "[2/6] Создание структуры пакета..."
BUILD_DIR="build/$PACKAGE_NAME-$VERSION"
rm -rf build
mkdir -p "$BUILD_DIR/DEBIAN"
mkdir -p "$BUILD_DIR/usr/share/applications"
mkdir -p "$BUILD_DIR/usr/share/pixmaps"
mkdir -p "$BUILD_DIR/usr/bin"
mkdir -p "$BUILD_DIR/usr/lib/armt-vpn"

# Копирование файлов приложения
echo "[3/6] Копирование файлов приложения..."
cp -r src/* "$BUILD_DIR/usr/lib/armt-vpn/"
cp armt-vpn.desktop "$BUILD_DIR/usr/share/applications/"
cp attached_assets/81018241-4148-45FC-B3A9-EDFFD93CCAB3_1761563132226.png "$BUILD_DIR/usr/share/pixmaps/"

# Создание исполняемого файла
echo "[4/6] Создание исполняемого файла..."
cat > "$BUILD_DIR/usr/bin/armt-vpn" << 'EOF'
#!/bin/bash
cd /usr/lib/armt-vpn
python3 main.py "$@"
EOF
chmod +x "$BUILD_DIR/usr/bin/armt-vpn"

# Создание control файла
echo "[5/6] Создание файла DEBIAN/control..."
cat > "$BUILD_DIR/DEBIAN/control" << EOF
Package: $PACKAGE_NAME
Version: $VERSION
Section: net
Priority: optional
Architecture: $ARCH
Depends: python3 (>= 3.6), python3-gi, gir1.2-gtk-3.0, python3-pil, python3-opencv, python3-pyzbar, python3-qrcode, python3-pyperclip
Maintainer: ARMT VPN Team <support@armt-vpn.local>
Description: VLESS VPN Client с графическим интерфейсом
 ARMT VPN - это графическое приложение для подключения к VLESS серверам.
 .
 Основные возможности:
  - Красивый графический интерфейс в синих и черных тонах
  - Импорт конфигураций из буфера обмена
  - Сканирование QR-кодов с VLESS конфигурациями
  - Управление несколькими конфигурациями
  - Простое подключение/отключение
Homepage: https://github.com/armt-vpn/armt-vpn
EOF

# Создание postinst скрипта
cat > "$BUILD_DIR/DEBIAN/postinst" << 'EOF'
#!/bin/bash
set -e

if [ "$1" = "configure" ]; then
    echo "ARMT VPN установлен успешно!"
    echo "Запустите приложение командой: armt-vpn"
    echo "Или найдите 'ARMT VPN' в меню приложений"
fi

exit 0
EOF
chmod +x "$BUILD_DIR/DEBIAN/postinst"

# Сборка пакета
echo "[6/6] Сборка .deb пакета..."
dpkg-deb --build "$BUILD_DIR"

# Перемещение готового пакета
DEB_FILE="${PACKAGE_NAME}_${VERSION}_${ARCH}.deb"
mv "build/${PACKAGE_NAME}-${VERSION}.deb" "$DEB_FILE"

echo ""
echo "========================================="
echo "✓ Сборка завершена успешно!"
echo "========================================="
echo ""
echo "Готовый пакет: $DEB_FILE"
echo ""
echo "Установка:"
echo "  sudo dpkg -i $DEB_FILE"
echo ""
echo "Если возникнут проблемы с зависимостями:"
echo "  sudo apt-get install -f"
echo ""
echo "Запуск:"
echo "  armt-vpn"
echo ""

# Проверка пакета
if command -v lintian &> /dev/null; then
    echo "Проверка пакета с помощью lintian..."
    lintian "$DEB_FILE" || true
fi
