"""
Модуль для парсинга VLESS конфигураций
"""

import re
from urllib.parse import urlparse, parse_qs
import base64

class VLESSParser:
    def __init__(self):
        pass
        
    def parse(self, vless_url):
        """
        Парсинг VLESS URL
        Формат: vless://UUID@SERVER:PORT?parameters#NAME
        """
        if not vless_url or not vless_url.startswith('vless://'):
            return None
            
        try:
            vless_url = vless_url.strip()
            
            url_parts = urlparse(vless_url)
            
            uuid = url_parts.username if url_parts.username else url_parts.path.split('@')[0].replace('vless://', '')
            
            server = url_parts.hostname
            port = url_parts.port if url_parts.port else 443
            
            params = parse_qs(url_parts.query)
            
            name = url_parts.fragment if url_parts.fragment else f"{server}:{port}"
            
            name = self._decode_name(name)
            
            config = {
                'name': name,
                'uuid': uuid,
                'server': server,
                'port': port,
                'type': params.get('type', ['tcp'])[0],
                'security': params.get('security', ['none'])[0],
                'encryption': params.get('encryption', ['none'])[0],
                'flow': params.get('flow', [''])[0],
                'sni': params.get('sni', [''])[0],
                'alpn': params.get('alpn', [''])[0],
                'fp': params.get('fp', [''])[0],
                'pbk': params.get('pbk', [''])[0],
                'sid': params.get('sid', [''])[0],
                'headerType': params.get('headerType', [''])[0],
                'host': params.get('host', [''])[0],
                'path': params.get('path', [''])[0],
                'serviceName': params.get('serviceName', [''])[0],
                'mode': params.get('mode', [''])[0],
            }
            
            config = {k: v for k, v in config.items() if v}
            
            return config
            
        except Exception as e:
            print(f"Ошибка парсинга VLESS URL: {e}")
            return None
            
    def _decode_name(self, name):
        """Декодирование имени конфигурации (может быть URL-encoded или base64)"""
        try:
            from urllib.parse import unquote
            decoded = unquote(name)
            return decoded
        except:
            return name
            
    def to_xray_config(self, config):
        """
        Преобразование в формат конфигурации Xray
        """
        xray_config = {
            "outbounds": [
                {
                    "protocol": "vless",
                    "settings": {
                        "vnext": [
                            {
                                "address": config.get('server'),
                                "port": config.get('port'),
                                "users": [
                                    {
                                        "id": config.get('uuid'),
                                        "encryption": config.get('encryption', 'none'),
                                        "flow": config.get('flow', '')
                                    }
                                ]
                            }
                        ]
                    },
                    "streamSettings": {
                        "network": config.get('type', 'tcp'),
                        "security": config.get('security', 'none')
                    }
                }
            ]
        }
        
        if config.get('security') == 'tls' or config.get('security') == 'reality':
            xray_config["outbounds"][0]["streamSettings"]["tlsSettings"] = {
                "serverName": config.get('sni', config.get('server')),
                "alpn": config.get('alpn', '').split(',') if config.get('alpn') else [],
                "fingerprint": config.get('fp', '')
            }
            
        if config.get('type') == 'ws':
            xray_config["outbounds"][0]["streamSettings"]["wsSettings"] = {
                "path": config.get('path', '/'),
                "headers": {
                    "Host": config.get('host', config.get('server'))
                }
            }
        elif config.get('type') == 'grpc':
            xray_config["outbounds"][0]["streamSettings"]["grpcSettings"] = {
                "serviceName": config.get('serviceName', '')
            }
            
        return xray_config
