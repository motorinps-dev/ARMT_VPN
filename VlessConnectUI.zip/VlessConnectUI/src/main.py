#!/usr/bin/env python3
"""
ARMT VPN - VLESS Client
Графическое приложение для подключения к VLESS конфигурациям
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib
import json
import os
from pathlib import Path
from vless_parser import VLESSParser
from qr_handler import QRHandler
from xray_manager import XrayManager
import pyperclip

class ARMTVPNApp(Gtk.Window):
    def __init__(self):
        super().__init__(title="ARMT VPN")
        self.set_default_size(800, 600)
        self.set_position(Gtk.WindowPosition.CENTER)
        
        self.config_file = Path.home() / '.config' / 'armt-vpn' / 'configs.json'
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        
        self.vless_parser = VLESSParser()
        self.qr_handler = QRHandler()
        self.xray_manager = XrayManager()
        self.configs = self.load_configs()
        self.connected = False
        
        self.load_css()
        self.build_ui()
        
    def load_css(self):
        """Загрузка CSS стилей"""
        css_provider = Gtk.CssProvider()
        css_file = Path(__file__).parent / 'style.css'
        css_provider.load_from_path(str(css_file))
        
        screen = Gdk.Screen.get_default()
        style_context = Gtk.StyleContext()
        style_context.add_provider_for_screen(
            screen,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
    def build_ui(self):
        """Построение интерфейса"""
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        main_box.get_style_context().add_class('main-window')
        
        header = self.create_header()
        main_box.pack_start(header, False, False, 0)
        
        content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        content_box.set_margin_top(30)
        content_box.set_margin_bottom(30)
        content_box.set_margin_start(30)
        content_box.set_margin_end(30)
        
        left_panel = self.create_left_panel()
        content_box.pack_start(left_panel, True, True, 0)
        
        right_panel = self.create_right_panel()
        content_box.pack_start(right_panel, True, True, 0)
        
        main_box.pack_start(content_box, True, True, 0)
        
        footer = self.create_footer()
        main_box.pack_end(footer, False, False, 0)
        
        self.add(main_box)
        
    def create_header(self):
        """Создание заголовка"""
        header_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        header_box.get_style_context().add_class('header')
        header_box.set_margin_top(40)
        header_box.set_margin_bottom(30)
        
        title_label = Gtk.Label()
        title_label.set_markup('<span size="xx-large" weight="bold">ARMT VPN</span>')
        title_label.get_style_context().add_class('title')
        
        subtitle_label = Gtk.Label(label="Защищенное подключение к VLESS серверам")
        subtitle_label.get_style_context().add_class('subtitle')
        
        header_box.pack_start(title_label, False, False, 0)
        header_box.pack_start(subtitle_label, False, False, 0)
        
        return header_box
        
    def create_left_panel(self):
        """Левая панель - управление подключением"""
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        panel.get_style_context().add_class('panel')
        
        status_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        status_box.get_style_context().add_class('status-box')
        status_box.set_size_request(350, 150)
        
        self.status_label = Gtk.Label(label="Отключено")
        self.status_label.get_style_context().add_class('status-disconnected')
        
        self.status_icon = Gtk.Label(label="🔒")
        self.status_icon.set_markup('<span size="xx-large">🔒</span>')
        
        status_box.pack_start(self.status_icon, True, True, 0)
        status_box.pack_start(self.status_label, False, False, 0)
        
        panel.pack_start(status_box, False, False, 0)
        
        self.connect_btn = Gtk.Button(label="Подключиться")
        self.connect_btn.get_style_context().add_class('btn-primary')
        self.connect_btn.set_size_request(250, 50)
        self.connect_btn.connect('clicked', self.on_connect_clicked)
        
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        btn_box.pack_start(Gtk.Label(), True, True, 0)
        btn_box.pack_start(self.connect_btn, False, False, 0)
        btn_box.pack_start(Gtk.Label(), True, True, 0)
        
        panel.pack_start(btn_box, False, False, 0)
        
        info_label = Gtk.Label()
        info_label.set_markup('<span size="small">Выберите конфигурацию\nили добавьте новую</span>')
        info_label.get_style_context().add_class('info-text')
        info_label.set_justify(Gtk.Justification.CENTER)
        panel.pack_start(info_label, False, False, 20)
        
        return panel
        
    def create_right_panel(self):
        """Правая панель - список конфигураций"""
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        panel.get_style_context().add_class('panel')
        
        header_label = Gtk.Label(label="Конфигурации")
        header_label.get_style_context().add_class('panel-header')
        panel.pack_start(header_label, False, False, 0)
        
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(300)
        
        self.config_listbox = Gtk.ListBox()
        self.config_listbox.get_style_context().add_class('config-list')
        self.config_listbox.connect('row-selected', self.on_config_selected)
        
        scrolled.add(self.config_listbox)
        panel.pack_start(scrolled, True, True, 0)
        
        self.refresh_config_list()
        
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        
        add_clipboard_btn = Gtk.Button(label="📋 Из буфера")
        add_clipboard_btn.get_style_context().add_class('btn-secondary')
        add_clipboard_btn.connect('clicked', self.on_add_from_clipboard)
        
        add_qr_btn = Gtk.Button(label="📷 Сканировать QR")
        add_qr_btn.get_style_context().add_class('btn-secondary')
        add_qr_btn.connect('clicked', self.on_scan_qr)
        
        btn_box.pack_start(add_clipboard_btn, True, True, 0)
        btn_box.pack_start(add_qr_btn, True, True, 0)
        
        panel.pack_start(btn_box, False, False, 0)
        
        return panel
        
    def create_footer(self):
        """Создание футера"""
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        footer.get_style_context().add_class('footer')
        footer.set_size_request(-1, 50)
        
        version_label = Gtk.Label(label="v1.0.0")
        version_label.get_style_context().add_class('footer-text')
        version_label.set_margin_start(20)
        
        footer.pack_start(version_label, False, False, 0)
        
        return footer
        
    def refresh_config_list(self):
        """Обновление списка конфигураций"""
        for child in self.config_listbox.get_children():
            self.config_listbox.remove(child)
            
        for config in self.configs:
            row = Gtk.ListBoxRow()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            box.set_margin_top(10)
            box.set_margin_bottom(10)
            box.set_margin_start(15)
            box.set_margin_end(15)
            
            name_label = Gtk.Label(label=config.get('name', 'Unnamed'))
            name_label.get_style_context().add_class('config-name')
            name_label.set_halign(Gtk.Align.START)
            
            server_label = Gtk.Label(label=config.get('server', ''))
            server_label.get_style_context().add_class('config-server')
            server_label.set_halign(Gtk.Align.START)
            
            info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
            info_box.pack_start(name_label, False, False, 0)
            info_box.pack_start(server_label, False, False, 0)
            
            box.pack_start(info_box, True, True, 0)
            
            delete_btn = Gtk.Button(label="🗑")
            delete_btn.get_style_context().add_class('btn-delete')
            delete_btn.connect('clicked', self.on_delete_config, config)
            box.pack_end(delete_btn, False, False, 0)
            
            row.add(box)
            self.config_listbox.add(row)
            
        self.config_listbox.show_all()
        
    def on_config_selected(self, listbox, row):
        """Обработка выбора конфигурации"""
        if row is not None:
            index = row.get_index()
            if 0 <= index < len(self.configs):
                self.selected_config = self.configs[index]
                
    def on_add_from_clipboard(self, button):
        """Добавление конфигурации из буфера обмена"""
        try:
            clipboard_text = pyperclip.paste()
            config = self.vless_parser.parse(clipboard_text)
            
            if config:
                self.configs.append(config)
                self.save_configs()
                self.refresh_config_list()
                self.show_message("Успех", "Конфигурация добавлена")
            else:
                self.show_message("Ошибка", "Неверный формат VLESS конфигурации")
        except Exception as e:
            self.show_message("Ошибка", f"Не удалось прочитать буфер обмена:\n{str(e)}")
            
    def on_scan_qr(self, button):
        """Сканирование QR-кода"""
        try:
            vless_url = self.qr_handler.scan_from_camera()
            
            if vless_url:
                config = self.vless_parser.parse(vless_url)
                if config:
                    self.configs.append(config)
                    self.save_configs()
                    self.refresh_config_list()
                    self.show_message("Успех", "Конфигурация из QR-кода добавлена")
                else:
                    self.show_message("Ошибка", "Неверный формат VLESS в QR-коде")
            else:
                self.show_message("Ошибка", "Не удалось отсканировать QR-код")
        except Exception as e:
            self.show_message("Ошибка", f"Ошибка сканирования:\n{str(e)}")
            
    def on_delete_config(self, button, config):
        """Удаление конфигурации"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text="Удалить конфигурацию?"
        )
        dialog.format_secondary_text(f"Удалить {config.get('name', 'эту конфигурацию')}?")
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            self.configs.remove(config)
            self.save_configs()
            self.refresh_config_list()
            
    def on_connect_clicked(self, button):
        """Обработка нажатия кнопки подключения"""
        if not self.connected:
            if not hasattr(self, 'selected_config'):
                self.show_message("Ошибка", "Выберите конфигурацию для подключения")
                return
                
            if not self.xray_manager.is_xray_installed():
                self.show_message(
                    "Xray-core не установлен",
                    "Для работы приложения требуется Xray-core.\n\n"
                    "Установите его командой:\n"
                    "sudo bash -c \"$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)\" @ install\n\n"
                    "Или посетите: https://github.com/XTLS/Xray-install"
                )
                return
                
            try:
                self.status_label.set_text("Подключение...")
                self.connect_btn.set_sensitive(False)
                
                while Gtk.events_pending():
                    Gtk.main_iteration()
                    
                self.xray_manager.start(self.selected_config)
                
                self.connected = True
                self.status_label.set_text("Подключено")
                self.status_label.get_style_context().remove_class('status-disconnected')
                self.status_label.get_style_context().add_class('status-connected')
                self.status_icon.set_markup('<span size="xx-large">✓</span>')
                self.connect_btn.set_label("Отключиться")
                self.connect_btn.get_style_context().remove_class('btn-primary')
                self.connect_btn.get_style_context().add_class('btn-danger')
                self.connect_btn.set_sensitive(True)
                
                proxy_settings = self.xray_manager.get_proxy_settings()
                self.show_message(
                    "Подключено успешно!",
                    f"Настройте ваше приложение/систему на использование прокси:\n\n"
                    f"SOCKS5: {proxy_settings['socks5']}\n"
                    f"HTTP: {proxy_settings['http']}\n\n"
                    f"Или используйте системные настройки прокси."
                )
                
            except Exception as e:
                self.status_label.set_text("Отключено")
                self.connect_btn.set_sensitive(True)
                self.show_message("Ошибка подключения", str(e))
        else:
            try:
                self.xray_manager.stop()
                self.connected = False
                self.status_label.set_text("Отключено")
                self.status_label.get_style_context().remove_class('status-connected')
                self.status_label.get_style_context().add_class('status-disconnected')
                self.status_icon.set_markup('<span size="xx-large">🔒</span>')
                self.connect_btn.set_label("Подключиться")
                self.connect_btn.get_style_context().remove_class('btn-danger')
                self.connect_btn.get_style_context().add_class('btn-primary')
            except Exception as e:
                self.show_message("Ошибка при отключении", str(e))
            
    def show_message(self, title, message):
        """Показ диалогового окна с сообщением"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
        
    def load_configs(self):
        """Загрузка конфигураций из файла"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []
        
    def save_configs(self):
        """Сохранение конфигураций в файл"""
        with open(self.config_file, 'w') as f:
            json.dump(self.configs, f, indent=2, ensure_ascii=False)

def main():
    app = ARMTVPNApp()
    
    def on_destroy(widget):
        if hasattr(app, 'xray_manager'):
            app.xray_manager.stop()
        Gtk.main_quit()
    
    app.connect('destroy', on_destroy)
    app.show_all()
    Gtk.main()

if __name__ == '__main__':
    main()
