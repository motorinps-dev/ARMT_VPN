"""
Модуль для управления Xray-core
Запуск, остановка и управление VLESS подключениями
"""

import subprocess
import json
import os
import signal
import tempfile
from pathlib import Path

class XrayManager:
    def __init__(self):
        self.process = None
        self.config_file = None
        self.xray_path = self._find_xray()
        
    def _find_xray(self):
        """Поиск исполняемого файла xray-core"""
        possible_paths = [
            '/usr/local/bin/xray',
            '/usr/bin/xray',
            str(Path.home() / '.local/bin/xray'),
            'xray'
        ]
        
        for path in possible_paths:
            if self._check_command(path):
                return path
        
        return None
        
    def _check_command(self, command):
        """Проверка доступности команды"""
        try:
            subprocess.run(
                [command, 'version'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=2
            )
            return True
        except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError):
            return False
            
    def is_xray_installed(self):
        """Проверка установки xray-core"""
        return self.xray_path is not None
        
    def create_config(self, vless_config):
        """
        Создание конфигурационного файла для Xray
        """
        xray_config = {
            "log": {
                "loglevel": "warning"
            },
            "inbounds": [
                {
                    "port": 10808,
                    "protocol": "socks",
                    "settings": {
                        "auth": "noauth",
                        "udp": True
                    },
                    "tag": "socks-in"
                },
                {
                    "port": 10809,
                    "protocol": "http",
                    "settings": {},
                    "tag": "http-in"
                }
            ],
            "outbounds": [
                {
                    "protocol": "vless",
                    "settings": {
                        "vnext": [
                            {
                                "address": vless_config.get('server'),
                                "port": int(vless_config.get('port', 443)),
                                "users": [
                                    {
                                        "id": vless_config.get('uuid'),
                                        "encryption": vless_config.get('encryption', 'none'),
                                        "flow": vless_config.get('flow', '')
                                    }
                                ]
                            }
                        ]
                    },
                    "streamSettings": {
                        "network": vless_config.get('type', 'tcp'),
                    },
                    "tag": "proxy"
                },
                {
                    "protocol": "freedom",
                    "tag": "direct"
                }
            ],
            "routing": {
                "rules": [
                    {
                        "type": "field",
                        "outboundTag": "direct",
                        "ip": [
                            "geoip:private"
                        ]
                    }
                ]
            }
        }
        
        security = vless_config.get('security', 'none')
        if security in ['tls', 'reality']:
            tls_settings = {
                "serverName": vless_config.get('sni', vless_config.get('server')),
                "allowInsecure": False
            }
            
            if vless_config.get('alpn'):
                tls_settings["alpn"] = vless_config.get('alpn').split(',')
                
            if vless_config.get('fp'):
                tls_settings["fingerprint"] = vless_config.get('fp')
                
            if security == 'tls':
                xray_config["outbounds"][0]["streamSettings"]["tlsSettings"] = tls_settings
            else:
                reality_settings = tls_settings.copy()
                if vless_config.get('pbk'):
                    reality_settings["publicKey"] = vless_config.get('pbk')
                if vless_config.get('sid'):
                    reality_settings["shortId"] = vless_config.get('sid')
                xray_config["outbounds"][0]["streamSettings"]["realitySettings"] = reality_settings
                
            xray_config["outbounds"][0]["streamSettings"]["security"] = security
            
        network_type = vless_config.get('type', 'tcp')
        if network_type == 'ws':
            ws_settings = {
                "path": vless_config.get('path', '/'),
            }
            if vless_config.get('host'):
                ws_settings["headers"] = {
                    "Host": vless_config.get('host')
                }
            xray_config["outbounds"][0]["streamSettings"]["wsSettings"] = ws_settings
            
        elif network_type == 'grpc':
            xray_config["outbounds"][0]["streamSettings"]["grpcSettings"] = {
                "serviceName": vless_config.get('serviceName', ''),
                "multiMode": vless_config.get('mode') == 'multi'
            }
            
        elif network_type == 'tcp' and vless_config.get('headerType'):
            xray_config["outbounds"][0]["streamSettings"]["tcpSettings"] = {
                "header": {
                    "type": vless_config.get('headerType')
                }
            }
            
        return xray_config
        
    def start(self, vless_config):
        """
        Запуск Xray с указанной конфигурацией
        """
        if not self.is_xray_installed():
            raise Exception("Xray-core не установлен. Установите его командой:\nsudo bash -c \"$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)\" @ install")
            
        if self.is_running():
            self.stop()
            
        xray_config = self.create_config(vless_config)
        
        temp_fd, self.config_file = tempfile.mkstemp(suffix='.json', prefix='armt-vpn-')
        os.close(temp_fd)
        
        with open(self.config_file, 'w') as f:
            json.dump(xray_config, f, indent=2)
            
        try:
            self.process = subprocess.Popen(
                [self.xray_path, 'run', '-c', self.config_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                start_new_session=True
            )
            
            import time
            time.sleep(1)
            
            if self.process.poll() is not None:
                stdout, stderr = self.process.communicate()
                raise Exception(f"Не удалось запустить Xray:\n{stderr.decode()}")
                
            return True
            
        except Exception as e:
            if self.config_file and os.path.exists(self.config_file):
                os.unlink(self.config_file)
            raise e
            
    def stop(self):
        """
        Остановка Xray
        """
        if self.process and self.process.poll() is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
                self.process.wait(timeout=5)
            except (ProcessLookupError, subprocess.TimeoutExpired):
                try:
                    os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
                except ProcessLookupError:
                    pass
                    
        self.process = None
        
        if self.config_file and os.path.exists(self.config_file):
            try:
                os.unlink(self.config_file)
            except:
                pass
            self.config_file = None
            
    def is_running(self):
        """
        Проверка статуса Xray
        """
        return self.process is not None and self.process.poll() is None
        
    def get_proxy_settings(self):
        """
        Получение настроек прокси для подключения
        """
        return {
            'socks5': 'socks5://127.0.0.1:10808',
            'http': 'http://127.0.0.1:10809',
        }
        
    def __del__(self):
        """
        Очистка при удалении объекта
        """
        self.stop()
