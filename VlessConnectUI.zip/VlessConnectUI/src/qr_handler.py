"""
Модуль для работы с QR-кодами
"""

import cv2
from pyzbar import pyzbar
from PIL import Image
import numpy as np

class QRHandler:
    def __init__(self):
        pass
        
    def scan_from_camera(self):
        """
        Сканирование QR-кода с камеры
        Возвращает текст из QR-кода или None
        """
        try:
            cap = cv2.VideoCapture(0)
            
            if not cap.isOpened():
                return None
                
            print("Камера открыта. Наведите QR-код на камеру. Нажмите 'q' для выхода.")
            
            while True:
                ret, frame = cap.read()
                
                if not ret:
                    break
                    
                decoded_objects = pyzbar.decode(frame)
                
                for obj in decoded_objects:
                    qr_data = obj.data.decode('utf-8')
                    
                    if qr_data.startswith('vless://'):
                        cap.release()
                        cv2.destroyAllWindows()
                        return qr_data
                        
                    points = obj.polygon
                    if len(points) > 4:
                        hull = cv2.convexHull(np.array([point for point in points], dtype=np.float32))
                        points = hull
                        
                    n = len(points)
                    for j in range(n):
                        cv2.line(frame, tuple(points[j]), tuple(points[(j+1) % n]), (0, 255, 0), 3)
                        
                cv2.imshow('QR Scanner - Press Q to quit', frame)
                
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                    
            cap.release()
            cv2.destroyAllWindows()
            return None
            
        except Exception as e:
            print(f"Ошибка при сканировании QR-кода: {e}")
            return None
            
    def scan_from_image(self, image_path):
        """
        Сканирование QR-кода из файла изображения
        """
        try:
            image = Image.open(image_path)
            
            decoded_objects = pyzbar.decode(image)
            
            for obj in decoded_objects:
                qr_data = obj.data.decode('utf-8')
                if qr_data.startswith('vless://'):
                    return qr_data
                    
            return None
            
        except Exception as e:
            print(f"Ошибка при чтении QR-кода из изображения: {e}")
            return None
            
    def generate_qr(self, vless_url, output_path='qr_code.png'):
        """
        Генерация QR-кода из VLESS URL
        """
        try:
            import qrcode
            
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            
            qr.add_data(vless_url)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            img.save(output_path)
            
            return output_path
            
        except Exception as e:
            print(f"Ошибка при генерации QR-кода: {e}")
            return None
